const fs = require('fs');
const path = require('path');
const JSZip = require('jszip');

async function createSourceZip() {
  const zip = new JSZip();
  const rootDir = path.resolve(__dirname, '..');

  const ignoredDirs = new Set([
    'node_modules',
    'dist',
    'dev-dist',
    '.git',
    '.aistudio',
    '.system_generated',
  ]);

  const ignoredFiles = new Set([
    'mahaschool-source-code.zip',
    'bun.lock',
  ]);

  function addFolderToZip(currentPath, zipFolder) {
    const items = fs.readdirSync(currentPath);

    for (const item of items) {
      const fullPath = path.join(currentPath, item);
      const stat = fs.statSync(fullPath);

      if (stat.isDirectory()) {
        if (!ignoredDirs.has(item) && !item.startsWith('.')) {
          const subFolder = zipFolder.folder(item);
          addFolderToZip(fullPath, subFolder);
        }
      } else if (stat.isFile()) {
        if (!ignoredFiles.has(item) && !item.endsWith('.zip')) {
          const content = fs.readFileSync(fullPath);
          zipFolder.file(item, content);
        }
      }
    }
  }

  console.log('Packaging project source files...');
  addFolderToZip(rootDir, zip);

  // Add README if not present in zip
  zip.file(
    'README.md',
    `# MahaSchool (महाराष्ट्र शाळा हजेरी व पोषण आहार प्रणाली)

A comprehensive, offline-first bilingual (Marathi/English) school management web and mobile application designed for Maharashtra Zilla Parishad, Municipal, and Aided schools.

## Features
- **Daily Student Attendance**: Class 1 to 8 roll call with absentee tracking and parent notice generation.
- **PM POSHAN (Mid-day meal) Calculator**: Daily grain, pulses, spices, oil, vegetable consumption based on official Maharashtra state norms (Primary: 100g rice, Upper Primary: 150g rice).
- **Ration Stock Inventory Ledger**: Track opening stock, daily cooking consumption, and incoming grain replenishment.
- **Official Notices & Absentee WhatsApp Messages**: Direct pre-formatted Devanagari text generation.
- **Offline Data Sync & Backup**: Works 100% without internet in remote villages with manual and automatic synchronization.
- **Android WebAPK / PWA Support**: Installable directly on Android phones with full-screen experience and app launcher icon.

## Quick Start

### 1. Install Dependencies
\`\`\`bash
npm install
\`\`\`

### 2. Run Development Server
\`\`\`bash
npm run dev
\`\`\`
The application will be running at http://localhost:3000

### 3. Build for Production
\`\`\`bash
npm run build
\`\`\`
Production static assets will be created in the \`dist/\` directory.
`
  );

  const outputDir = path.join(rootDir, 'public');
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const outputPath = path.join(outputDir, 'mahaschool-source-code.zip');
  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  fs.writeFileSync(outputPath, buffer);
  const sizeMb = (buffer.length / (1024 * 1024)).toFixed(2);
  console.log('Successfully generated ' + outputPath + ' (' + sizeMb + ' MB)');
}

createSourceZip().catch((err) => {
  console.error('Error generating source zip:', err);
  process.exit(1);
});
