# MahaSchool (महाराष्ट्र शाळा हजेरी व पोषण आहार प्रणाली)

A comprehensive, offline-first bilingual (Marathi/English) school management web and mobile application designed for Maharashtra Zilla Parishad, Municipal, and Aided schools.

## Features
- **Daily Student Attendance**: Class 1 to 8 roll call with absentee tracking and parent notice generation.
- **PM POSHAN (Mid-day meal) Calculator**: Daily grain, pulses, spices, oil, vegetable consumption based on official Maharashtra state norms (Primary: 100g rice, Upper Primary: 150g rice).
- **Ration Stock Inventory Ledger**: Track opening stock, daily cooking consumption, and incoming grain replenishment.
- **Official Notices & Absentee WhatsApp Messages**: Direct pre-formatted Devanagari text generation.
- **Offline Data Sync & Backup**: Works 100% without internet in remote villages with manual and automatic synchronization.
- **Android WebAPK / PWA Support**: Installable directly on Android phones with full-screen experience and app launcher icon.

## Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Run Development Server
```bash
npm run dev
```
The application will be running at http://localhost:3000

### 3. Build for Production
```bash
npm run build
```
Production static assets will be created in the `dist/` directory.
